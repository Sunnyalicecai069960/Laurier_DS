/*
 ============================================================================
 Name        : caix8870_a04q1.c
 Author      : tingting Cai
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<string.h>

#define MAXBYTES 1000
#define MAXWORDS 80

struct word {
	char word[MAXWORDS];
	int counter;
};
void trim(char*);
void lowercase(char*);
void encounter(char*);

int main(int argsc, char * args[]) {
	FILE *file = fopen(args[1], "r");
	FILE *result = fopen(args[2], "w+");
	char line[MAXBYTES];
	int lineNum = 0;
	int wordNum = 0;
	int i = 0;
	int k = 0;
	struct word words[MAXWORDS];
	const char delimiters[] = " .\n\t\r";
	char *token;

	if (file == NULL) {
		printf("the file %s doesn't exist!", args[1]);
		return -1;
	}

	if (result == NULL) {
		printf("The file doesn't open!");
		return -1;
	}
	while (!feof(file)) {
		fgets(line, MAXBYTES, file);

		lowercase(line);
		trim(line);

		token = strtok(line, delimiters);
		while (token != NULL) {
			wordNum++;
			for (k = 0; k <= i; k++) {
				if (strcmp(words[k].word, token) == 0) {
					words[k].counter++;
					break;
				}
			}
			if (k > i || i == 0) {
				strcpy(words[i].word, token);
				words[i].counter = 1;
				i++;
			}
			token = strtok(NULL, delimiters);
		}

		lineNum++;
	}

	fprintf(result, "Line Count%15d\n", lineNum);
	fprintf(result, "Word Count%15d\n", wordNum);
	fprintf(result, "Frequency\n");
	printf("Line Count%15d\n", lineNum);
	printf("Word Count%15d\n", wordNum);
	printf("Frequency\n");

	for (k = 0; k < i; k++) {
		fprintf(result, "%-20s%5d\n", words[k].word, words[k].counter);
		printf("%-20s%5d\n", words[k].word, words[k].counter);
	}
	fclose(file);
	fclose(result);
	return EXIT_SUCCESS;
}

void trim(char *s) {
	char *str;
	int index = 0;
	str = s;
	while (*s != '\0') {
		if (*s != ' ') {
			*str = *s;
			*(str++);
			*(s++);
			index = -1;
		} else {
			if (index == -1) {
				*str = ' ';
				*(str++);
			}
			index++;
			*(s++);
		}
	}
	*str = '\0';
}

void lowercase(char *s) {

	while (*s != '\0') {
		if (*s >= 'A' && *s <= 'Z')
			*s = *s + 32;
		*(s++);
	}
}
