/*
 ============================================================================
 Name        : caix8870_a04q2.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include <math.h>

#define MAXNAME 80
#define MAXSTUDENT 200
#define LINE 100
typedef struct {
	char name[MAXNAME];
	float score;
} record;
/**
 *  import data from the input file, and store all entries in dataset[], and return the number of records read.
 */
int data_import(record dataset[], char* infilename);
/**
 *  compute  the average score, standard deviation and letter grades, output the results on screen and file.
 */
void data_report(record dataset[], int count, char* outfilename);
/**
 * convert a float score to a letter grade according to ranges A=[85, 100], B=[70, 85), C=[60, 70), D=[50,60), F=[0,50).
 */
char letter_grade(float score);

int main(int argsc, char * args[]) {
	record dataset[MAXSTUDENT];
	int total;

	total = data_import(dataset, args[1]);
	if (total == -1) {
		printf("the file doesn't exist");
		return -1;
	}
	data_report(dataset, total, args[2]);

	return EXIT_SUCCESS;
}

int data_import(record dataset[], char* infilename) {
	FILE *file = fopen(infilename, "r");
	char line[LINE];
	const char delimiters[] = ",\n";
	char *token;
	int total = 0;

	if (file == NULL) {
		printf("the file doesn't exist");
		return -1;
	}

	while (!feof(file)) {
		fgets(line, LINE, file);

		token = strtok(line, delimiters);
		if (token != NULL)
			strcpy(dataset[total].name, token);

		token = strtok(NULL, delimiters);
		if (token != NULL)
			dataset[total].score = atof(token);

		total++;
	}
	fclose(file);
	return total;
}

void data_report(record dataset[], int count, char* outfilename) {
	FILE *file = fopen(outfilename, "w+");
	float total = 0.0;
	float average = 0.0;
	float sd = 0.0;
	int i = 0;

	if (file == NULL) {
		printf("the file doen't open!");
	}

	for (i = 0; i < count; i++) {
		total += dataset[i].score;
	}

	average = total / count;
	total = 0.0;
	for (i = 0; i < count; i++) {
		total += pow(dataset[i].score - average, 2);
	}

	sd = pow(total / count, 0.5);

	fprintf(file, "Letter Grade\n");
	printf("Letter Grade\n");
	for (i = 0; i < count; i++) {
		fprintf(file, "%-20s%3c\n", dataset[i].name,
				letter_grade(dataset[i].score));
		printf("%-20s%3c\n", dataset[i].name, letter_grade(dataset[i].score));
	}
	printf("Summary\n");
	printf("%-20s%3d\n", "record count", count);
	printf("%-20s%3.1f\n", "average", average);
	printf("%-20s%3.1f", "standard deviation", sd);
	fprintf(file, "Summary\n");
	fprintf(file, "%-20s%3d\n", "record count", count);
	fprintf(file, "%-20s%3.1f\n", "average", average);
	fprintf(file, "%-20s%3.1f", "standard deviation", sd);
	fclose(file);
}

char letter_grade(float score) {

	if (score >= 85.0 && score <= 100.0)
		return 'A';
	else if (score >= 70.0 && score < 85.0)
		return 'B';
	else if (score >= 60.0 && score < 70.0)
		return 'C';
	else if (score >= 50.0 && score < 60.0)
		return 'D';
	else if (score >= 0.0 && score < 50.0)
		return 'F';
	return 'F';
}
