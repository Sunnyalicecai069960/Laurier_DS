Name:Tingting Cai
ID:174178870
Email:caix8870@mylaurier.ca
Assignment_ID: cp264a4
Homework statement: I claim that the enclosed submission is my individual work 

Check list, self-evaulation/marking, marking scheme:
Note: fill self-evaluation for each of the following bracket under A1 marks and evalutions below. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2  like [2/2]. If 
marker gives different evalution value say 1, it will show [2/2/1] in the marking report. 

marks and evaluations:
q1 
1. file read all lines                          [3/3] 
2. structure and array                          [3/3]
3. string tokenize and data retrival            [6/6]
3. file output	                                [3/3] 
                                    
q2
1. structure and array                          [5/5] 
2. data import                                  [5/5] 
3. data reprot                                  [5/5]

Total:                                          [30/30] 

