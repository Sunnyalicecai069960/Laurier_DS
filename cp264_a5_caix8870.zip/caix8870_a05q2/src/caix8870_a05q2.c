/*
 ============================================================================
 Name        : caix8870_a05q2.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include <math.h>

#define MAXNAME 80
#define MAXSTUDENT 200
#define LINE 100
typedef struct {
	char name[MAXNAME];
	float score;
	struct record *next;
} record;
int count = 0;
/**
 *  import data from the input file, and store all entries in dataset[], and return the number of records read.
 */
void data_import(record** start, char* infilename);
/**
 *  compute  the average score, standard deviation and letter grades, output the results on screen and file.
 */
void data_report(record ** start, char* outfilename);
/**
 *  insert a reconrd into the linked list sorted by name
 */
void insert(record** start, char* name, float score);
/**
 * delete a reconrd of the name from the linked list
 */
void delete(record** start, char* name);
/**
 * convert a float score to a letter grade according to ranges A=[85, 100], B=[70, 85), C=[60, 70), D=[50,60), F=[0,50).
 */
char letter_grade(float score);
/**
 * display the records
 */
void display(record *start);

int main(int argsc, char * args[]) {
	record *dataset = NULL;

	data_import(&dataset, args[1]);
	display(dataset);
	if (count == -1) {
		printf("the file doesn't exist");
		return -1;
	}
	insert(&dataset, "Moore", 92.0);
	delete(&dataset, "Wang");
	data_report(&dataset, args[2]);

	return EXIT_SUCCESS;
}

void data_import(record **dataset, char* infilename) {
	FILE *file = fopen(infilename, "r");
	char line[LINE];
	const char delimiters[] = ",\n";
	char *token;
	char *name;
	float score = 0;
	record *node;

	if (file == NULL) {
		printf("the file doesn't exist");
		count = -1;
	}

	while (!feof(file)) {
		fgets(line, LINE, file);
		token = strtok(line, delimiters);
		node = (record*) malloc(sizeof(record));
		if (token != NULL)
			name = token;

		token = strtok(NULL, delimiters);
		if (token != NULL)
			score = atof(token);

		insert(dataset, name, score);

		count++;
	}
	fclose(file);
}
void insert(record **startp, char* name, float score) {

	if (*startp == NULL) {
		record *np = (record*) malloc(sizeof(record));
		strcpy(np->name, name);
		np->score = score;
		np->next = *startp;
		*startp = np;
		return;
	}
	record *current = *startp;
	record *prev = NULL;
	record *temp = NULL;
	record *node = (record*) malloc(sizeof(record));

	strcpy(node->name, name);
	node->score = score;

	do {
		prev = current;
		current = current->next;
		if (prev == *startp && strcmp(prev->name, node->name) > 0) {
			node->next = prev;
			*startp = node;
			return;
		} else if (current == NULL && strcmp(prev->name, node->name) < 0) {
			prev->next = node;
			node->next = NULL;
			return;
		} else if (strcmp(prev->name, node->name) < 0
				&& strcmp(current->name, node->name) > 0) {
			temp = prev->next;
			prev->next = node;
			node->next = temp;
			return;
		}

	} while (current != NULL);
}
void data_report(record **dataset, char* outfilename) {
	FILE *file = fopen(outfilename, "w+");
	float total = 0.0;
	float average = 0.0;
	float sd = 0.0;
	record *ptr = *dataset;

	if (file == NULL) {
		printf("the file doen't open!");
	}

	while (ptr != NULL) {
		total += ptr->score;
		ptr = ptr->next;
	}

	average = total / count;
	total = 0.0;
	ptr = *dataset;
	while (ptr != NULL) {
		total += pow(ptr->score - average, 2);
		ptr = ptr->next;
	}

	sd = pow(total / count, 0.5);

	ptr = *dataset;
	fprintf(file, "Letter Grade\n");
	printf("Letter Grade\n");
	while (ptr != NULL) {
		fprintf(file, "%-20s%3c\n", ptr->name, letter_grade(ptr->score));
		printf("%-20s%3c\n", ptr->name, letter_grade(ptr->score));
		ptr = ptr->next;
	}
	printf("Summary\n");
	printf("%-20s%3d\n", "record count", count);
	printf("%-20s%3.1f\n", "average", average);
	printf("%-20s%3.1f", "standard deviation", sd);
	fprintf(file, "Summary\n");
	fprintf(file, "%-20s%3d\n", "record count", count);
	fprintf(file, "%-20s%3.1f\n", "average", average);
	fprintf(file, "%-20s%3.1f", "standard deviation", sd);
	fclose(file);
}

char letter_grade(float score) {

	if (score >= 85.0 && score <= 100.0)
		return 'A';
	else if (score >= 70.0 && score < 85.0)
		return 'B';
	else if (score >= 60.0 && score < 70.0)
		return 'C';
	else if (score >= 50.0 && score < 60.0)
		return 'D';
	else if (score >= 0.0 && score < 50.0)
		return 'F';
	return 'F';
}
void delete(record** start, char* name) {
	record *ptr = *start;
	record *prev;
	do {
		prev = ptr;
		ptr = ptr->next;
		if (prev == *start && strcmp(prev->name, name) == 0) {
			*start = ptr;
			free(prev);
			return;
		} else if (strcmp(ptr->name, name) == 0 && ptr->next == NULL) {
			prev->next = NULL;
			free(ptr);
		} else if (strcmp(ptr->name, name) == 0 && ptr->next != NULL
				&& prev != *start) {
			prev->next = ptr->next;
			free(ptr);
		}
	} while (ptr->next != NULL);
}
void display(record *start) {
	while (start != NULL) {
		printf("%s %.2f\n", start->name, start->score);
		start = start->next;
	}
	printf("\n");
}
