/*
 ============================================================================
 Name        : caix8870_a05q1.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#define MAX 1000
typedef struct {
	char data;
	struct Link *pre;
	struct Link *next;
} Link;

int main(void) {
	char str[MAX];
	int i = 0;
	Link * start, *ptr, *list;

	setbuf(stdout, NULL);
	printf("input the number you want to input:");
	scanf("%s", str);

	while (str[i] != '\0') {
		if (start == NULL) {
			list = (Link*) malloc(sizeof(Link));
			list->data = str[i];
			list->next = NULL;
			list->pre = NULL;
			start = list;
		} else {
			ptr = start;
			list = (Link*) malloc(sizeof(Link));
			list->data = str[i];
			while (ptr->next != NULL) {
				ptr = ptr->next;
			}
			ptr->next = list;
			list->pre = ptr;
			printf("%c", ptr->data);
			list->next = NULL;
		}
		i++;
	}

	printf("In forward direction:\n");
	while (start->next != NULL) {
		printf("%c,", start->data);
		start = start->next;
	}
	printf("%c", start->data);

	printf("\nIn backward direction:\n");
	while (start->pre != NULL) {
		printf("%c,", start->data);
		start = start->pre;
	}
	printf("%c", start->data);
	return EXIT_SUCCESS;
}
