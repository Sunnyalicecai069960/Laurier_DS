Name:Tingting Cai
ID:174178870
Email:caix8870@mylaurier.ca
Assignment_ID: cp264a5
Homework statement: I claim that the enclosed submission is my individual work 

Check list, self-evaulation/marking, marking scheme:
Note: fill self-evaluation for each of the following bracket under A1 marks and evalutions below. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2  like [2/2]. If 
marker gives different evalution value say 1, it will show [2/2/1] in the marking report. 

marks and evaluations:
q1 
1. double linked list insert functions          [3/3] 
2. forward and backward display functions       [3/3]
3. main, read string and build dlist            [4/4] 
                                    							
q2
1. node and linked list                         [4/4] 
2. insert and delete functions                  [4/4] 
3. data import                                  [4/4]
4. data report                                  [4/4]
5. file organization                            [4/4]

Total:                                          [30/30] 
