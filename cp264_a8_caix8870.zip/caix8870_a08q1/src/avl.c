/*
 * avl.c
 *
 *  Created on: 2017��3��5��
 *      Author: ������
 */
#include"avl.h"

void print_avltree(node *tree, int prelen) {
	int i;
	if (tree) {
		for (i = 0; i < prelen; i++)
			printf("%c", ' ');
		printf("%s", "|___");
		printf("%d\n", tree->key);
		print_avltree(tree->left, prelen + 4);
		print_avltree(tree->right, prelen + 4);
	}
}

int avlis_balanced(node *node) {
	if (!node)
		return 1;
	if (abs(balance_factor(node)) > 1)
		return 0;
	else
		return avlis_balanced(node->left) && avlis_balanced(node->right);
}
// A utility function to get height of the tree
int height(node *N) {
	if (N == NULL)
		return 0;
	return N->height;
}

// A utility function to get maximum of two integers
int max(int a, int b) {
	return (a > b) ? a : b;
}

/* Helper function that allocates a new node with the given key and
 NULL left and right pointers. */
node* newnode(int key) {
	node* avl = (node*) malloc(sizeof(node));
	avl->key = key;
	avl->left = NULL;
	avl->right = NULL;
	avl->height = 1;  // new node is initially added at leaf
	return (avl);
}

// A utility function to right rotate subtree rooted with y
// See the diagram given above.
node *rightRotate(node *y) {
	node *x = y->left;
	node *T2 = x->right;

	// Perform rotation
	x->right = y;
	y->left = T2;

	// Update heights
	y->height = max(height(y->left), height(y->right)) + 1;
	x->height = max(height(x->left), height(x->right)) + 1;

	// Return new root
	return x;
}

// A utility function to left rotate subtree rooted with x
// See the diagram given above.
node *leftRotate(node *x) {
	node *y = x->right;
	node *T2 = y->left;

	// Perform rotation
	y->left = x;
	x->right = T2;

	//  Update heights
	x->height = max(height(x->left), height(x->right)) + 1;
	y->height = max(height(y->left), height(y->right)) + 1;

	// Return new root
	return y;
}

// Get Balance factor of node N
int balance_factor(node *N) {
	if (N == NULL)
		return 0;
	return height(N->left) - height(N->right);
}

node* insert(node* node, int key) {
	/* 1.  Perform the normal BST rotation */
	if (node == NULL) {
		return (newnode(key));
	}

	if (key < node->key)
		node->left = insert(node->left, key);
	else if (key > node->key)
		node->right = insert(node->right, key);
	else
		// Equal keys not allowed
		return node;

	/* 2. Update height of this ancestor node */
	node->height = 1 + max(height(node->left), height(node->right));

	/* 3. Get the balance factor of this ancestor
	 node to check whether this node became
	 unbalanced */
	int balance = balance_factor(node);
//	if ((node->left && node->left->key == key)
//			|| (node->right && node->right->key == key))
//		printf("Insert:%d,Ancestor node:%d,Balance Factor:%d\n", key, node->key,
//				balance_factor(node));

	// If this node becomes unbalanced, then there are 4 cases

	// Left Left Case
	if (balance > 1 && key < node->left->key)
		return rightRotate(node);

	// Right Right Case
	if (balance < -1 && key > node->right->key)
		return leftRotate(node);

	// Left Right Case
	if (balance > 1 && key > node->left->key) {
		node->left = leftRotate(node->left);
		return rightRotate(node);
	}

	// Right Left Case
	if (balance < -1 && key < node->right->key) {
		node->right = rightRotate(node->right);
		return leftRotate(node);
	}

	/* return the (unchanged) node pointer */
	return node;
}

/* Given a non-empty binary search tree, return the
 node with minimum key value found in that tree.
 Note that the entire tree does not need to be
 searched. */
node * find_smallest_node(node* avlNode) {
	node* current = avlNode;

	/* loop down to find the leftmost leaf */
	while (current->left != NULL)
		current = current->left;

	return current;
}

// Recursive function to delete a node with given key
// from subtree with given root. It returns root of
// the modified subtree.
node* delete(node* root, int key) {
	// STEP 1: PERFORM STANDARD BST DELETE

	if (root == NULL)
		return root;

	// If the key to be deleted is smaller than the
	// root's key, then it lies in left subtree
	if (key < root->key)
		root->left = delete(root->left, key);

	// If the key to be deleted is greater than the
	// root's key, then it lies in right subtree
	else if (key > root->key)
		root->right = delete(root->right, key);

	// if key is same as root's key, then This is
	// the node to be deleted
	else {
		// node with only one child or no child
		if ((root->left == NULL) || (root->right == NULL)) {
			node *temp = root->left ? root->left : root->right;

			// No child case
			if (temp == NULL) {
				temp = root;
				root = NULL;
			} else
				// One child case
				*root = *temp; // Copy the contents of
							   // the non-empty child
			free(temp);
		} else {
			// node with two children: Get the inorder
			// successor (smallest in the right subtree)
			node* temp = find_smallest_node(root->right);

			// Copy the inorder successor's data to this node
			root->key = temp->key;

			// Delete the inorder successor
			root->right = delete(root->right, temp->key);
		}
	}

	// If the tree had only one node then return
	if (root == NULL)
		return root;

	// STEP 2: UPDATE HEIGHT OF THE CURRENT node
	root->height = 1 + max(height(root->left), height(root->right));

	// STEP 3: GET THE BALANCE FACTOR OF THIS node (to
	// check whether this node became unbalanced)
	int balance = balance_factor(root);

	// If this node becomes unbalanced, then there are 4 cases

	// Left Left Case
	if (balance > 1 && balance_factor(root->left) >= 0)
		return rightRotate(root);

	// Left Right Case
	if (balance > 1 && balance_factor(root->left) < 0) {
		root->left = leftRotate(root->left);
		return rightRotate(root);
	}

	// Right Right Case
	if (balance < -1 && balance_factor(root->right) <= 0)
		return leftRotate(root);

	// Right Left Case
	if (balance < -1 && balance_factor(root->right) > 0) {
		root->right = rightRotate(root->right);
		return leftRotate(root);
	}

	return root;
}

// A utility function to print print_preorder traversal of
// the tree.
// The function also prints height of every node
void print_preorder(node *root) {
	if (root != NULL) {
		printf("%d (%d,%d)", root->key, balance_factor(root), root->height);
		print_preorder(root->left);
		print_preorder(root->right);
	}
}

node* search(node* avl, int key) {
	if (!avl)
		return NULL;

	if (avl->key == key)
		return avl;
	else if (avl->key > key > 0)
		search(avl->left, key);
	else
		search(avl->right, key);
}

void print_inorder(node * root) {
	if (root != NULL) {
		print_inorder(root->left);
		printf("%d (%d,%d)", root->key, balance_factor(root), root->height);
		print_inorder(root->right);
	}
}
