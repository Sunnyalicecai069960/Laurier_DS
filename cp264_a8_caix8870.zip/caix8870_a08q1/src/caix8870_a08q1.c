/*
 ============================================================================
 Name        : caix8870_a08q1.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "avl.h"

int main(int argc, char* args[]) {

	int n = atoi(args[1]);
	node *root = NULL, *np;
	int i;
	for (i = 1; i <= n; i++) {
		root = insert(root, i);
	}

	print_preorder(root);
	printf("\n");
	print_inorder(root);
	printf("\n");

	for (i = 1; i <= n; i++) {
		if (i % 2 == 0)
			root = delete(root, i);
	}

	print_preorder(root);
	printf("\n");
	print_inorder(root);
	printf("\n");

	for (i = 1; i <= n; i++) {
		np = search(root, i);
		if (np == NULL)
			printf("not found %d\n", i);
		else
			printf("found %d\n", np->key);
	}

	return 0;
}

