/*
 * avl.h
 *
 *  Created on: 2017��3��6��
 *      Author: ������
 */


#ifndef AVL_H
#define AVL_H

#include<stdio.h>
#include<stdlib.h>

struct Node {
	int key;
	int height;
	struct Node *left;
	struct Node *right;

};

typedef struct Node node;

node* new_node(int);
node* right_rotate(node *);
node* left_rotate(node *);
node* insert(node*, int);
node* delete(node*, int);
node* search(node*, int);
node* find_smallest_node(node *);
int height(node*);
int get_height(node*);
int balance_factor(node*);
void print_preorder(node *);
void print_inorder(node *);
int max(int a, int b);

#endif

