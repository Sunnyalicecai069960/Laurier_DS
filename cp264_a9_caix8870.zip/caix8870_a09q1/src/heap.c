/*
 * heap.c
 *
 *  Created on: 2017��3��20��
 *      Author: ������
 */
#include "bheap.h"
heap *new_heap(int cap) {
	heap * Heap = (heap*) malloc(sizeof(heap));
	int *data = (int *) malloc(sizeof(int) * cap);
	Heap->data = data;
	Heap->capacity = cap;
	Heap->size = 0;
	return Heap;
}
void insert(heap* Heap, int val) {
	if (Heap->size + 1 == Heap->capacity) {
		int *new_data = (int*) realloc(Heap->data,
				sizeof(int) * Heap->capacity * 2);
		if (new_data == NULL) {
			new_data = (int *) malloc(sizeof(int) * Heap->capacity * 2);
			Heap->data = memcpy(new_data, Heap->data, Heap->capacity);
		} else
			Heap->data = new_data;
		Heap->capacity = Heap->capacity * 2;
	}
	Heap->data[Heap->size] = val;
	heapify_up(Heap, Heap->size);

}
void heapify_up(heap *Heap, int index) {
	int par_index = (index - 1) / 2;
	int val = Heap->data[index];

	while (index > 0) {
		if (Heap->data[par_index] <= val)
			break;
		else {
			Heap->data[index] = Heap->data[par_index];
			index = par_index;
			par_index = (par_index - 1) / 2;
		}
	}
	Heap->data[index] = val;
	Heap->size++;
}
void delete(heap *Heap) {

	Heap->data[0] = Heap->data[Heap->size - 1];
	Heap->size--;
	if (Heap->size <= (Heap->capacity / 4)) {
		int *new_data = (int*) realloc(Heap->data,
				sizeof(int) * (Heap->capacity / 2));
		Heap->data = memcpy(new_data, Heap->data, Heap->capacity / 2);
		Heap->capacity = Heap->capacity / 2;
	}
	heapify_down(Heap, 0, Heap->size - 1);
}
void heapify_down(heap *Heap, int index, int n) {
	int val = Heap->data[index];
	int l = 2 * index + 1;
	while (l <= n) {
		if (l < n && Heap->data[l] > Heap->data[l + 1])
			l++;
		if (val <= Heap->data[l])
			break;
		else {
			Heap->data[index] = Heap->data[l];
			index = l;
			l = 2 * l + 1;
		}
	}
	Heap->data[index] = val;
//	display(Heap);
}
int peek(heap* Heap) {
	return Heap->data[0];
}
void display(heap* Heap) {
	int i;
	for (i = 0; i < Heap->size; i++) {
		printf("%d ", Heap->data[i]);
	}
	printf("\n");
}
