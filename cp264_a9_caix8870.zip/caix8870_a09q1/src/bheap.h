/*
 * bheap.h
 *
 *  Created on: 2017��3��20��
 *      Author: ������
 */

#ifndef BHEAP_H_
#define BHEAP_H_
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#define MIN_CAPACITY 4
#define CMP(a, b) ((a) <= (b))

typedef struct HEAP {
	unsigned int capacity;
	unsigned int size;
	int *data;
} heap;

heap *new_heap(int);
void insert(heap*, int);
void delete(heap *);
int peek(heap*);
void display(heap*);
void heapify_up(heap *Heap, int index);
void heapify_down(heap *Heap, int index, int n);

#endif /* BHEAP_H_ */
