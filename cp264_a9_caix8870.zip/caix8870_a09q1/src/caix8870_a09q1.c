/*
 ============================================================================
 Name        : caix8870_a09q1.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "bheap.h"

int main(int arg, char *args[]) {
	int i, n = atoi(args[1]);

	heap *hp = new_heap(4);
	if (hp->data == NULL)
		return 0;

	printf("size=%d;capacity=%d\n", hp->size, hp->capacity);
	for (i = 1; i <= n; i++) {
		insert(hp, n - i);
	}

	display(hp);
	printf("\nsize=%d;capacity=%d\n", hp->size, hp->capacity);

	for (i = 0; i < 4 * n / 5; i++) {
		printf("%d ", peek(hp));
		delete(hp);
	}

	printf("\nsize=%d;capacity=%d\n", hp->size, hp->capacity);

	for (i = 0; i < hp->size; i++) {
		printf("%d ", hp->data[i]);
	}
	printf("\nsize=%d;capacity=%d\n", hp->size, hp->capacity);

	return 0;
}
