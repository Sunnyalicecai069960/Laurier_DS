/*
 * llstack.h
 *
 *  Created on: 2017��3��20��
 *      Author: ������
 */

#ifndef LLSTACK_H_
#define LLSTACK_H_


#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>
#include "hash.h"
struct STACK {
	int data;
	struct STACK *next;
};

typedef struct STACK stack;

extern stack *top;
void push(stack**, int);
void pop(stack**);
int peek(stack*);
void clean(stack*);

void InfixtoPostfix(char *source, char *target);
int evaluatePostfixExp(char exp[]);
int getPriority(char);
void statement_process(char *line);
int is_number(char * s);

int infix_eval(char exp[]);
int isOperator(char);
int isSymbol(char);

#endif /* LLSTACK_H_ */
