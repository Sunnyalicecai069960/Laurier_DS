/*
 ============================================================================
 Name        : caix8870_a09q2.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "llstack.h"

hashdata* hashmap[SIZE];
stack *top;

int main(int argc, char* args[]) {
	char line[100];
	FILE *fp = fopen(args[1], "r");
	if (fp == NULL) {
		perror("Error while opening the file.\n");
		exit(EXIT_FAILURE);
	}

	char delimiters1[] = ";\n ";
	char *st;
	while (fgets(line, sizeof(line), fp) != NULL) {
		st = strtok(line, delimiters1);
//		printf("%s\n", st);
		/**
		 *if right is number,insert into hashmap
		 *else evaluate,then insert
		 */
		statement_process(st);
	}
	fclose(fp);

	display();
	return 0;
}
