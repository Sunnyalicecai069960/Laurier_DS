/*
 * hesh.h
 *
 *  Created on: 2017��3��20��
 *      Author: ������
 */

#ifndef HASH_H_
#define HASH_H_
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#define SIZE 20

typedef struct DataItem {
	int key;
	char name[10];
	int data;
} hashdata;

int hash(char *);
hashdata *search(char *name);
void put(char *name, int data);
int get(char *name);
int contains(char *);
void display();
int size();


#endif /* HASH_H_ */
