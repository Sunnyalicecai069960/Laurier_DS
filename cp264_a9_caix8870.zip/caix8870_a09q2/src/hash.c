/*
 * hash.c
 *
 *  Created on: 2017��3��20��
 *      Author: ������
 */

#include "hash.h"
extern hashdata* hashmap[SIZE];
int hash(char * str) {
	int i = 0, hash = 0;
	for (; str[i] != '\0'; i++)
		hash += str[i];
	return hash % SIZE;
}
hashdata *search(char *name) {
//	int i = 0;
//	for (; i < SIZE; i++) {
//		if (strcmp(hashmap[i]->name, name) == 0)
//			return hashmap[i];
//	}
//	return NULL;
	if (contains(name))
		return hashmap[hash(name)];
	return NULL;
}
void put(char *name, int data) {
	hashdata * item = (hashdata*) malloc(sizeof(hashdata));
	int key = hash(name);
	item->data = data;
	item->key = key;
	strcpy(item->name, name);

	hashmap[key] = item;
}
int get(char *name) {
//	int i = 0;
//	for (; i < SIZE; i++) {
//		if (hashmap[i] != NULL)
//			if (strcmp(hashmap[i]->name, name) == 0)
//				return hashmap[i]->data;
//	}
	return hashmap[hash(name)]->data;
}
int contains(char * name) {
//	int i = 0;
//	for (; i < SIZE; i++) {
//		if (hashmap[i] != NULL)
//			if (strcmp(hashmap[i]->name, name) == 0)
//				return 1;
//	}
//	return 0;
	if (hashmap[hash(name)] != NULL)
		return 1;
	return 0;
}
void display() {
	int i = 0;
	for (; i < SIZE; i++) {
		if (hashmap[i] != NULL)
			printf("%s=%d\n", hashmap[i]->name, hashmap[i]->data);
	}
}
int size() {
	int size = 0;
	int i = 0;
	for (; i < SIZE; i++) {
		if (hashmap[i] != NULL)
			size++;
	}
	return size;
}

