/*
 * llstack.c
 *
 *  Created on: 2017��3��20��
 *      Author: ������
 */

#include "llstack.h"

extern stack *top;

int is_number(char * s) {
	int i = 0;
	if (s[i] == '.')
		return 0;
	else {
		i++;
		while (s[i] != '\0') {
			if (!isdigit(s[i]))
				return 0;
			i++;
		}
	}
	return 1;
}
void statement_process(char *line) {
	char delimiters1[] = "=";
	char left[100];
	char right[100];

	strcpy(left, strtok(line, delimiters1));
	strcpy(right, strtok(NULL, delimiters1));
	//if only number
	if (is_number(right) != 0)
		put(left, atoi(right));
	else {
		put(left, infix_eval(right));
	}
}
int infix_eval(char exp[]) {
	char postfix[100];
	InfixtoPostfix(exp, postfix);

	return evaluatePostfixExp(postfix);
}
int isOperator(char op) {
	if (op == '+' || op == '-' || op == '*' || op == '/' || op == '%')
		return 1;
	return 0;
}
int isSymbol(char sy) {
	if (isalpha(sy))
		return 1;
	return 0;
}
void push(stack **start, int val) {
	stack *ptr;
	ptr = (stack*) malloc(sizeof(stack));
	ptr->data = val;
	if (*start == NULL) {
		ptr->next = NULL;
		*start = ptr;
	} else {
		ptr->next = *start;
		*start = ptr;
	}
}

void pop(stack **start) {
	stack *ptr;
	ptr = *start;
	if (*start == NULL)
		printf("\nSTACK UNDERFLOW");
	else {
		*start = (*start)->next;
		free(ptr);
	}
}

int peek(stack *top) {
	if (top == NULL)
		return -1;
	else
		return top->data;
}

void clean(stack *start) {
	stack* temp;
	while (start != NULL) {
		temp = start;
		start = start->next;
		free(temp);
	}
}

int getPriority(char op) {
	if (op == '/' || op == '*' || op == '%')
		return 1;
	else if (op == '+' || op == '-')
		return 0;
	return 0;
}

void InfixtoPostfix(char *source, char *target) {
// your implementation
	int i = 0, j = 0;
	char temp;

	strcpy(target, "");

	while (source[i] != '\0') {

		if (source[i] == '(') {
			push(&top, source[i]);
			i++;
		} else if (source[i] == ')') {

			while (top != NULL && peek(top) != '(') {
				target[j] = peek(top);
				pop(&top);
				j++;
			}

			if (top == NULL) {
				printf("\n INCORRECT EXPRESSION");
				exit(1);
			}

			temp = peek(top);
			pop(&top);
			i++;
		} else if (isdigit(source[i]) || isalpha(source[i])) {
			target[j] = source[i];
			j++;
			i++;

		} else if (source[i] == '+' || source[i] == '-' || source[i] == '*'
				|| source[i] == '/' || source[i] == '%') {

			while (top != NULL && peek(top) != '('
					&& (getPriority(peek(top)) > getPriority(source[i]))) {
				target[j] = peek(top);
				pop(&top);
				j++;
			}

			push(&top, source[i]);
			i++;
		} else {
			printf("\nINCORRECT ELEMENT IN EXPRESSION");
			exit(1);
		}
	}
	while (top != NULL && peek(top) != '(') {
		target[j] = peek(top);
		pop(&top);
		j++;
	}
	target[j] = '\0';
}

int evaluatePostfixExp(char exp[]) {
// your implementation
	int i = 0;
	int op1, op2, value;
	while (exp[i] != '\0') {
		if (isdigit(exp[i])) {
			push(&top, exp[i] - '0');
		} else if (isalpha(exp[i])) {
			char temp[2] = { '\0' };
			temp[0] = exp[i];
			if (contains(temp))
				push(&top, get(temp));
		} else {
			op2 = peek(top);
			pop(&top);
			op1 = peek(top);
			pop(&top);
			switch (exp[i]) {
			case '+':
				value = op1 + op2;
				break;
			case '-':
				value = op1 - op2;
				break;
			case '/':
				value = op1 / op2;
				break;
			case '*':
				value = op2 * op1;
				break;
			case '%':
				value = op1 % op2;
				break;
			}
			push(&top, value);
		}
		i++;
	}
	value = peek(top);
	pop(&top);
	return value;
}
