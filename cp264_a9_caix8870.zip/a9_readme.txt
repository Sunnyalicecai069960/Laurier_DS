Name:TingtingCai	
ID:174178870	
Email:caix8870@mylaurier.ca
Assignment_ID: cp264a9
Homework statement: I claim that the enclosed submission is my individual work 

Check list, self-evaulation/marking, marking scheme:
Note: fill self-evaluation for each of the following bracket. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2  like [2/2]. If marker gives different evalution value say 1, it will show [2/2/1] in the marking report. 

marks and evaluations:
q1 
1. heap structure, new_heap, peek, display      [5/5] 
2. insert function                              [5/5]
3. delte  function                              [5/5]

q2 
1. hash data structure and operations           [5/5] 
2. put and get functions                        [5/5]
3. infix_eval, statement_process                [5/5]

Total:                                          [30/30] 

