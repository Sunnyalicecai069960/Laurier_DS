Name:Tingting Cai
ID:174178870
Email:caix8870@mylaurier.ca
Assignment_ID: cp264a7
Homework statement: I claim that the enclosed submission is my individual work 

Check list, self-evaulation/marking, marking scheme:
Note: fill self-evaluation for each of the following bracket under A1 marks and evalutions below. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2  like [2/2]. If 
marker gives different evalution value say 1, it will show [2/2/1] in the marking report. 

marks and evaluations:
q1 
1. binary tree data structure                   [3/3] 
2. pre-order, in-order, post-order              [3/3]
3. breadth-first-order                          [3/3]
4. node count, height                           [3/3]
5. main function                                [3/3]
	
q2
1. node and binary tree                         [3/3] 
2. insert function                              [3/3] 
3. delete function                              [3/3]
4. data import                                  [3/3]
5. data report                                  [3/3]


Total:                                          [30/30] 
