/*
 ============================================================================
 Name        : caix8870_a07q1.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include<stdlib.h>
#include<stdio.h>

struct tree_node {
	char data;
	struct tree_node *left, *right;
};

struct queue_node {
	struct tree_node* tnode;
	struct queue_node *next;
};

typedef struct tree_node node;

typedef struct queue_node qnode;

int count;
node *new_node(char);
void node_count(node*);
int tree_height(node*);
void print_preorder(node*);
void print_inorder(node*);
void print_postorder(node*);
node *dfs(node*, char);
void bfs(node*);
void print_tree(node*, int);
void clean_tree(node*);

qnode *enqueue(qnode*, node*);
qnode *dequeue(qnode*);
void clean_queue(qnode*);

int main() {
	node *np, *root;
	root = NULL;

	node *n1 = new_node('A');
	node *n2 = new_node('B');
	node *n3 = new_node('C');
	node *n4 = new_node('D');
	node *n5 = new_node('E');
	node *n6 = new_node('G');
	node *n7 = new_node('F');

	n1->left = n2;
	n1->right = n3;
	n2->left = n4;
	n2->right = n5;
	n3->left = n6;
	n3->right = n7;

	root = n1;

//	printf("tree style\n");
//	print_tree(root, 0);

	printf("\npre-order: ");
	print_preorder(root);

	printf("\nin-order: ");
	print_inorder(root);

	printf("\npost-order: ");
	print_postorder(root);

	printf("\nbreadth-first-order: ");
	bfs(root);

	count = 0;
	node_count(root);
	printf("\nnode count:%d", count);
	printf("\ntree height:%d", tree_height(root));

	clean_tree(root);

	return 0;
}

node *new_node(char data) {
	node *np = (node *) malloc(sizeof(node));
	if (np == NULL)
		return NULL;
	np->data = data;
	np->left = NULL;
	np->right = NULL;
	return np;
}

void print_preorder(node *tree) {
	if (tree) {
		printf("%c ", tree->data);
		print_preorder(tree->left);
		print_preorder(tree->right);
	}
}

void print_inorder(node *tree) {
	if (tree) {
		print_inorder(tree->left);
		printf("%c ", tree->data);
		print_inorder(tree->right);
	}
}

void print_postorder(node *tree) {
	if (tree) {
		print_postorder(tree->left);
		print_postorder(tree->right);
		printf("%c ", tree->data);
	}
}

void print_tree(node *tree, int prelen) {
	int i;
	if (tree != NULL) {
		for (i = 0; i < prelen; i++)
			printf("%c", ' ');
		printf("%s", "|___");
		printf("%c\n", tree->data);
		print_tree(tree->left, prelen + 4);
		print_tree(tree->right, prelen + 4);
	}
}

void clean_tree(node *tree) {
	if (tree) {
		clean_tree(tree->left);
		clean_tree(tree->right);
		free(tree);
	}
}

node *dfs(node *tree, char data) {
	if (!tree) {
		return NULL;
	}
	node *np;

	if (data == tree->data)
		return tree;

	np = dfs(tree->left, data);
	if (np)
		return np;
	else
		return dfs(tree->right, data);

	return NULL;
}

qnode *enqueue(qnode *rear, node *treenode) {
	qnode *qnp = (qnode*) malloc(sizeof(qnode));
	if (!qnp)
		return rear;
	qnp->tnode = treenode;
	qnp->next = NULL;

	if (rear != NULL) {
		rear->next = qnp;
	}
	rear = qnp;
	return rear;
}

qnode *dequeue(qnode *front) {
	if (!front)
		return NULL;
	return front->next;
}

void clean_queue(qnode *front) {
	qnode* temp;
	while (front != NULL) {
		temp = front;
		front = front->next;
		free(temp);
	}
}

void bfs(node *tree) {
	if (!tree) {
		printf("NULL tree");
	}
	node *np;
	qnode *front = NULL, *rear = NULL;

	rear = enqueue(rear, tree);
	front = rear;

	while (front) {
		if (front->tnode) {
			printf("%c ", front->tnode->data);
//			if (front->tnode->data == data) {
//				np = front->tnode;
//				clean_queue(front);
//				return np;
//			}
			rear = enqueue(rear, front->tnode->left);
			rear = enqueue(rear, front->tnode->right);
			front = dequeue(front);
		} else {
			front = dequeue(front);
		}
	}
}
void node_count(node* tree) {
	if (tree) {
		count++;
		if (tree->left)
			node_count(tree->left);
		node_count(tree->right);
	}
}
int tree_height(node* tree) {
	if (!tree)
		return 0;
	if (tree) {
		int m = tree_height(tree->left);
		int n = tree_height(tree->right);
		return (m > n) ? (m + 1) : (n + 1);
	}
}
