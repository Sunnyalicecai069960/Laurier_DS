/*
 * tree.h
 *
 *  Created on: 2017��2��26��
 *      Author: ������
 */

#ifndef TREE_H_
#define TREE_H_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct NODE {
	char name[40];
	float score;
	struct NODE *left, *right;
};

typedef struct NODE node;

void display(node *);
node* search(node*, char*);
void insert(node**, char*, float);
void delete(node**, char*);
void clean_tree(node*);

void data_report(node*, char*);
void data_import(node**, char*);
char letter_grade(float);
int get_node_count(node*);
float get_sum(node*);
float get_square_sum(node*, float);
node *find_smallest_element(node*);
void report_file(node*, FILE*);


#endif /* TREE_H_ */
