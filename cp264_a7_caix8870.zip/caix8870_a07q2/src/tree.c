/*
 * tree.c
 *
 *  Created on: 2017��2��26��
 *      Author: ������
 */
#include "tree.h"

void display(node *tree) {
	if (tree) {
		display(tree->left);
		printf("%s %.2f\n", tree->name, tree->score);
		display(tree->right);
	}
}
void insert_node(node **treepp, node *newnode) {
	if (*treepp == NULL) {
		*treepp = newnode;
		return;
	}

	if (strcmp(newnode->name, (*treepp)->name) < 0)
		insert_node(&(*treepp)->left, newnode);
	else if (strcmp(newnode->name, (*treepp)->name) > 0)
		insert_node(&(*treepp)->right, newnode);
	else {
		printf("node of the value exits\n");
		free(newnode);
	}
}
void insert(node **treepp, char *name, float score) {
	node *newnode = (node *) malloc(sizeof(node));
	if (newnode == NULL)
		return;
	strcpy(newnode->name, name);
	newnode->score = score;
	newnode->left = NULL;
	newnode->right = NULL;

// your implementation
	if (*treepp == NULL) {
		*treepp = newnode;
		return;
	}

	if (strcmp(newnode->name, (*treepp)->name) < 0)
		insert_node(&(*treepp)->left, newnode);
	else if (strcmp(newnode->name, (*treepp)->name) > 0)
		insert_node(&(*treepp)->right, newnode);
	else {
		printf("node of the value exits\n");
		free(newnode);
	}
}

void delete(node **treepp, char *name) {
// implementation
	node *root = *treepp;
	node* temp;
	char *nodeName = (*treepp)->name;
	if (!root)
		printf("the tree is null");

	if (strcmp(root->name, name) == 0) {
		if (!root->left && !root->right) {
			free(root);
			*treepp = NULL;
		}
		if (root->left && !root->right) {
			temp = root->left;
			free(root);
			*treepp = temp;

		}
		if (root->right && !root->left) {
			temp = root->right;
			free(root);
			*treepp = temp;
		}
		if (root->left && root->right) {
			temp = find_smallest_element(root->right);
			strcpy(root->name, temp->name);
			root->score = temp->score;
			delete(&(root->right), temp->name);
		}
	} else {
		if (strcmp(root->name, name) < 0) {
			delete(&(root->right), name);
		} else {
			delete(&(root->left), name);
		}
	}
}

node* search(node *tree, char *name) {
// your implementation
	if (!tree)
		return NULL;

	if (strcmp(tree->name, name) == 0)
		return tree;
	else if (strcmp(tree->name, name) > 0)
		search(tree->left, name);
	else
		search(tree->right, name);
}

void data_report(node *tree, char *filename) {
	node *current = tree;
	FILE *fp = fopen(filename, "w");
	int count = get_node_count(tree);
	float sum = get_sum(tree);
	float mean = sum / count;

	float stddv = sqrt(get_square_sum(tree, mean) / count);

	fprintf(fp, "letter grade\n");
	fprintf(stdout, "letter grade\n");

	report_file(tree, fp);

	fprintf(fp, "\nsummary\n");
	fprintf(fp, "%-20s%d\n", "record count:", count);
	fprintf(fp, "%-20s%3.1f\n", "average", mean);
	fprintf(fp, "%-20s%3.1f\n", "standard deviation", stddv);
	fclose(fp);

	fprintf(stdout, "\nsummary\n");
	fprintf(stdout, "%-20s%d\n", "record count:", count);
	fprintf(stdout, "%-20s%3.1f\n", "average", mean);
	fprintf(stdout, "%-20s%3.1f\n", "standard deviation", stddv);
}

void data_import(node **treep, char *filename) {
	char line[40], name[20];
	FILE *fp = fopen(filename, "r");
	char *result = NULL;
	char delimiters[] = ",\n";
	float score = 0;

	printf("%s", filename);
	if (fp == NULL) {
		perror("Error while opening the file.\n");
		exit(EXIT_FAILURE);
	}

	while (fgets(line, sizeof(line), fp) != NULL) {
		result = strtok(line, delimiters);
		strcpy(name, result);
		result = strtok(NULL, delimiters);
		score = atof(result);
//		printf("%s %.2f\n", name, score);
		insert(treep, name, score);
	}
	fclose(fp);
}

char letter_grade(float score) {
	if ((100 >= score) && (score >= 85))
		return 'A';
	else if ((85 > score) && (score >= 70))
		return 'B';
	else if ((70 > score) && (score >= 60))
		return 'C';
	else if ((60 > score) && (score >= 50))
		return 'D';
	else
		return 'F';
}

void clean_tree(node *tree) {
// implementation
	if (tree) {
		if (tree->left)
			clean_tree(tree->left);
		if (tree->right)
			clean_tree(tree->right);
		free(tree);
	}
}

int get_node_count(node* tree) {
// from q1
	if (!tree)
		return 0;
	return get_node_count(tree->left) + get_node_count(tree->right) + 1;
}

float get_sum(node* tree) {
// compute the sum of all scores
	if (!tree)
		return 0;

	return tree->score + get_sum(tree->right) + get_sum(tree->left);
}

float get_square_sum(node *tree, float mean) {
	if (!tree)
		return 0;
	return (tree->score - mean) * (tree->score - mean)
			+ get_square_sum(tree->left, mean)
			+ get_square_sum(tree->right, mean);
}

node *find_smallest_element(node *tree) {
// used by delete
	if (!tree || !tree->left)
		return tree;
	else
		return find_smallest_element(tree->left);
}

void report_file(node *tree, FILE *fp) {
	if (tree) {
		if (tree->left)
			report_file(tree->left, fp);
		fprintf(fp, "%-15s%c\n", tree->name, letter_grade(tree->score));
		fprintf(stdout, "%-15s%c\n", tree->name, letter_grade(tree->score));
		if (tree->right)
			report_file(tree->right, fp);
	}
}

