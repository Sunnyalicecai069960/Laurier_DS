/*
 ============================================================================
 Name        : caix8870_a07q2.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tree.h"

int main(int argc, char* args[]) {
	node *root = NULL;

	data_import(&root, args[1]);

	printf("Display\n");
	display(root);

	insert(&root, "Moore", 92.0);

	struct NODE *p = search(root, "Moore");
	if (p == NULL)
		printf("Not Fount\n");
	else
		printf("Found: %.2f\n", p->score);

	delete(&root, "Wang");
//
	data_report(root, args[2]);

	clean_tree(root);

	return 0;
}

