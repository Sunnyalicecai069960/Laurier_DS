/*
 ============================================================================
 Name        : caix8870_a06q1.c
 Author      : tingting Cai
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

struct dnode {
	int data;
	struct dnode *next;
	struct dnode *prev;
};

typedef struct dnode node;

node* new_dlnode(int data);
void insert_beg(node**, node**, node*);
void insert_end(node**, node**, node*);
void display_forward(node *lnode);
void clean(node *lnode);

// compute the sum of op1 and op2 starting from tail and add result to result linked list
void sum(node *op1_tail, node *op2_tail, node **result_head, node **result_tail);

int main(int argc, char* args[]) {
	//char *p = "11111111111111111111+88888888888888888889";
	char *p = args[1];
	node *op1_head = NULL, *op1_tail = NULL, *op2_head = NULL, *op2_tail = NULL,
			*result_head = NULL, *result_tail = NULL;
	char operator = '+';
	int i = 0;
	node* newNode = NULL;
	// scan the string to get first operand to store in op1 linked list,
	// get the oprator,
	// get the second operand to store in op2 linked list,
	while (*(p + i) != operator) {
		newNode = new_dlnode(*(p + i) - '0');
		insert_end(&op1_head, &op1_tail, newNode);
		i++;
	}
	i++;
	while (*(p + i) != '\0') {
		newNode = new_dlnode(*(p + i) - '0');
		insert_end(&op2_head, &op2_tail, newNode);
		i++;
	}
	// diplay op1
	// print the operator
	// diplay op2
	display_forward(op1_head);
	printf("+");
	display_forward(op2_head);
	printf("\n=");

	sum(op1_tail, op2_tail, &result_head, &result_tail);
// diplay result
	display_forward(result_head);
// clean up
	clean(op1_head);
	clean(op2_head);
	clean(result_head);
	return 0;;
}

node* new_dlnode(int data) {
	node* np = (node *) malloc(sizeof(node));
	np->data = data;
	np->prev = NULL;
	np->next = NULL;
	return np;
}

void insert_beg(node **headp, node **tailp, node *newnode) {
	node* np = *headp;
	if (*headp == NULL) {
		*headp = newnode;
		*tailp = *headp;
		newnode->prev = NULL;
	} else {
		np->prev = newnode;
		newnode->next = *headp;
	}
	*headp = newnode;
	newnode->prev = NULL;
}

void insert_end(node **headp, node **tailp, node *newnode) {
	node* np = *tailp;
	if (*headp == NULL) {
		*headp = newnode;
		newnode->prev = NULL;
	} else {
		np->next = newnode;
		newnode->prev = *tailp;
	}
	*tailp = newnode;
	newnode->next = NULL;
}

void display_forward(node *start) {
	while (start != NULL) {
		printf("%d", start->data);
		start = start->next;
	}
}

void clean(node *start) {
	node* temp;
	while (start != NULL) {
		temp = start;
		start = start->next;
		free(temp);
	}
}

void sum(node *oprand1_tail, node *oprand2_tail, node **result_head,
		node **result_tail) {
// your implementation
	int carrier = 0;
	int sum = 0;
	node* newNode;
	while (oprand1_tail != NULL && oprand2_tail != NULL) {
		if (carrier != 0) {
			sum += carrier;
			carrier = 0;
		}
		sum += oprand1_tail->data + oprand2_tail->data;
		if (sum > 9) {
			sum = sum % 10;
			carrier = 1;
		}
		newNode = new_dlnode(sum);
		insert_beg(result_head, result_tail, newNode);
		oprand1_tail = oprand1_tail->prev;
		oprand2_tail = oprand2_tail->prev;
		sum = 0;
	}
	if (oprand1_tail == NULL && oprand2_tail != NULL) {
		while (oprand2_tail != NULL) {
			if (carrier != 0) {
				sum += carrier;
				carrier = 0;
			}
			sum += oprand2_tail->data;
			if (sum > 9) {
				sum = sum % 10;
				carrier = 1;
			}
			newNode = new_dlnode(sum);
			insert_beg(result_head, result_tail, newNode);
			oprand2_tail = oprand2_tail->prev;
			sum = 0;
		}
	}
	if (oprand2_tail == NULL && oprand1_tail != NULL) {
		while (oprand1_tail != NULL) {
			if (carrier != 0) {
				sum += carrier;
				carrier = 0;
			}
			sum += oprand1_tail->data;
			if (sum > 9) {
				sum = sum % 10;
				carrier = 1;
			}
			newNode = new_dlnode(sum);
			insert_beg(result_head, result_tail, newNode);
			oprand1_tail = oprand1_tail->prev;
			sum = 0;
		}
	}
	if (carrier != 0) {
		newNode = new_dlnode(carrier);
		insert_beg(result_head, result_tail, newNode);
	}
}

