/*
 * llstack.h
 *
 *  Created on: 2017��2��17��
 *      Author: ������
 */

/*
 * file name: llstack.h
 */
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>

struct STACK {
	int data;
	struct STACK *next;
};

typedef struct STACK stack;

extern stack *top;
void push(stack**, char);
void pop(stack**);
int peek(stack*);
void clean(stack*);

void InfixtoPostfix(char source[], char target[]);
float evaluatePostfixExp(char exp[]);
int getPriority(char);


