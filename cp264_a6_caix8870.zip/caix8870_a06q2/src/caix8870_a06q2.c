/*
 ============================================================================
 Name        : caix8870_a06q2.c
 Author      : tingting Cai
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include "llstack.h"
stack *top;
int main(int argc, char *args[]) {
	char* infix = args[1]; //"9-((3*4)+8)/4";
	char postfix[100];
	InfixtoPostfix(infix, postfix);
	clean(top);  // top = -1 for array stack
	float val = evaluatePostfixExp(postfix);
	printf("%s=%d", infix, (int) val);
	return 0;
}

