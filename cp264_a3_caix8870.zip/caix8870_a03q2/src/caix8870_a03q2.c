/*
 ============================================================================
 Name        : caix8870_a03q2.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

void trim(char*s);
void lowercase(char*s);
int strlength(char *s);
char* readfile(char filename[]);
int main(int argc, char * args[]) {
	char str[100];
	setbuf(stdout, NULL);
	//read string from file
	FILE *fp;
	if ((fp = fopen(args[1], "r")) == NULL) {
		printf("Open failed");
		return -1;
	}
	while (!feof(fp)) {
		fgets(str, 100, fp);
	}
	fclose(fp);
	// observe the before
	printf("Before processing:\"%s\"", str);
	printf("\nBefore length:%d", strlength(str));

	trim(str);
	lowercase(str);

	printf("\n After processing:\"%s\"", str);
	printf("\nAfter length:%d", strlength(str));

	return EXIT_SUCCESS;
}

void trim(char *s) {
	char *str;
	int index = 0;
	str = s;
	while (*s != '\0') {
		if (*s != ' ') {
			*str = *s;
			*(str++);
			*(s++);
			index = -1;
		} else {
			if (index == -1) {
				*str = ' ';
				*(str++);
			}
			index++;
			*(s++);
		}
	}
	*str = '\0';
}

void lowercase(char *s) {

	while (*s != '\0') {
		if (*s >= 'A' && *s <= 'Z')
			*s = *s + 32;
		*(s++);
	}
}

int strlength(char *s) {
	int i = 0;
	while (*s != '\0') {
		*(s++);
		i++;
	}
	return i + 1;
}

char* readfile(char filename[]) {
	char *buffer = NULL;
	int string_size, read_size;
	FILE *handler = fopen(filename, "r");
	if (handler) {
		//seek the last byte of the file
		fseek(handler, 0, SEEK_END);
		//offset from the first tot he last byte ,or in other words,filesize
		string_size = ftell(handler);
		//go back to the start of the file
		rewind(handler);

		//allocate a string that can hold it all
		buffer = (char*) malloc(sizeof(char) * (string_size + 1));
		//read it all in one operation
		read_size = fread(buffer, sizeof(char), string_size, handler);
		//fread doesn't set it so put na \0 in the last position
		//and buffer is now officially a string
		buffer[string_size + 1] = '\0';

		if (string_size != read_size) {
			//something went wrong. throw away the memory and set the buffer to NULL
			free(buffer);
			buffer = NULL;
		}
	}
	return buffer;
}
