/*
 ============================================================================
 Name        : caix8870_a03q1.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

void matrix_display(int*, int);
void magic_saquare(int*, int);
void sum_diagonal(int*, int);
void transpose(int*, int);

int main(void) {
	int n;
	setbuf(stdout, NULL);
	while (1) {
		printf("Input a positive odd integer,or 0 to quit:");
		scanf("%d", &n);
		if (n != 0) {
			if (n % 2 != 0) {
			int mat[n][n];
			int i, j;
			for (i = 0; i < n; i++) {
				for (j = 0; j < n; j++) {
					mat[i][j] = 0;
				}
			}
			int *m = &mat[0][0];
		magic_saquare(m, n);
		matrix_display(m, n);
		sum_diagonal(m, n);
		transpose(m, n);
			} else {
				printf("Please input an odd number!\n");
			}
		} else {
			printf("Exit");
			break;
		}
		fflush(stdin);
	}
	return EXIT_SUCCESS;
}

void matrix_display(int *m, int n) {
	int col, row;
	int *p = m;
	printf("The magic square of order %d is\n", n);
	for (row = 0; row < n; row++) {
		for (col = 0; col < n; col++) {
			printf("%6d", *(p++));
		}
		printf("\n");
		}
}

void magic_saquare(int *m, int n) {
	int i, col, row;

	col = (n - 1) / 2;
	row = 0;

	*(m + row * n + col + 1) = 1;
	for (i = 2; i < n * n; i++) {
		if ((i - 1) % n == 0) {
			row++;
		} else {
			row--;
			row = (row + n) % n;
			col++;
			col %= n;
		}
		*(m + row * n + col + 1) = i;
	}

}

void sum_diagonal(int *m, int n) {
	int i;
	int sum = 0;

	for (i = 0; i < n; i++) {
		sum += *(m + i * n + i + 1);
	}
	printf("Diagonal sum is %d\n", sum);
}

void transpose(int *m, int n) {
	int trans[n][n];
	int i, j;

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) {
			trans[i][j] = *(m + j * n + i + 1);
		}
}
	int *mat = &trans[0][0];
	matrix_display(mat, n);

}
