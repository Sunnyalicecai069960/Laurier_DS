Name:Tingting Cai	
ID:174178870
Email:caix8870@mylaurier.ca
Assignment_ID: cp264a3
Homework statement: I claim that the enclosed submission is my individual work 

Check list, self-evaulation/marking, marking scheme:
Note: fill self-evaluation for each of the following bracket under A1 marks and evalutions below. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2  like [2/2]. If 
marker gives different evalution value say 1, it will show [2/2/1] in the marking report. 

marks and evaluations:
q1 
1. user interace input/output  					[3/3] 
2. magic square funtion 						[6/6] -4 if just use the given 3 by 3 magic square
3. diagonal sum	             					[3/3] 
4. transpose                             		[3/3] 

q2
1. char array and string read     				[3/3] 
2. trim function                             	[6/6] front, middle and end, each values 2 points. 
3. string lenght function                     	[3/3] 
4. lower case function   					    [3/3] 

Total:                                          [30/30] 

