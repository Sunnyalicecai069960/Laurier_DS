Name:TingtingCai
ID:174178870
Email:caix8870@mylaurier.ca
Assignment_ID: cp264a1
Homework statement: I claim that the enclosed submission is my individual work 

Check list, self-evaulation/marking, marking scheme:
Note: fill self-evaluation for each of the following bracket under A1 marks and evalutions below. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2  like [2/2]. If 
marker gives different evalution value say 1, it will show [2/2/1] in the marking report. 

A1 marks and evaluations:
Q1
1. prompt for input                   [2/2]  
2. input lower case                   [2/2]
3. input upper case                   [2/2]
4. robus for bad input                [2/2] 
5. repeat and quit                    [2/2] 

Q2
1. command line argument              [2/2]
2. Correctness of computing results   [4/4]
3. correct output format              [2/2]  


Q3
1. prompt for input                   [2/2]
2. correctness of solution            [4/4]
3. robus for bad input                [2/2] 

testing batch and result              [4/4]

Total:                               [30/30]