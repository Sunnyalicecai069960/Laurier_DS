/*
 -------------------------------------------------------
 Project: a1q3
 File:    a1q3.c
 -------------------------------------------------------
 Author:  Tingting Cai
 ID: 174178870
 Email:   caix8870@mylaurier.ca
 Version: 1
 -------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include<string.h>
int main(void) {
	float a, b, c;
	float res1, res2;
	float d, e, f;
	int count = 0;
	setbuf(stdout, NULL);
	while (1) {
		printf("please enter the coefficients a,b,c(example:2,2,1):");
		count = scanf("%f,%f,%f", &a, &b, &c);
		fflush(stdin);
		if (count == 3) {
			if (fabs(a) <= 1e-6) {
				printf("Not a quadratic equation\n");
			} else if (fabs(b * b - 4 * a * c) < 1e-6) {
				res1 = -b / (2 * a);
				printf("The equation has two equal roots:%8.4f\n", res1);
			} else if (b * b - 4 * a * c < 1e-6) {
				d = sqrt(4 * a * c - b * b);
				e = -b / (2 * a);
				f = d / (2 * a);
				printf(
						"The equation has complex roots: \n %8.4f+%8.4fi \n%8.4f-%8.4fi\n",
						e, f, e, f);
			} else if (b * b - 4 * a * c > 0) {
				d = sqrt(b * b - 4 * a * c);
				e = -b / (2 * a);
				f = d / (2 * a);
				res1 = e + f;
				res2 = e - f;
				printf("The equation has distinct real roots:%8.4f and %8.4f\n",
						res1, res2);
			}
		} else
			printf("please input a valid a,b,c in valid format\n");

	}
	return EXIT_SUCCESS;
}
