/*
 -------------------------------------------------------
 Project: a1q2
 File:    a1q2.c
 -------------------------------------------------------
 Author:  Tingting Cai
 ID: 174178870
 Email:   caix8870@mylaurier.ca
 Version: 14
 -------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include<ctype.h>
int main(void) {
	int n;
	int i;
	char exit = 'Y';
	char str[10];
	long int result[40];
	setbuf(stdout, NULL);
	while (1) {
		printf("\na1q2->please input the number of the sequence:");
		scanf("%s", &str);
		/*
		 * 1,if other data type
		 * 2,if character
		 */
		for (i = 0; i < strlen(str); i++) {
			if (isalpha(str[i]))
				continue;
			if (str[i] == '.')
				continue;
		}
		n = atoi(str);
		fflush(stdin);
	if (n == 1) {
		printf("1");
	} else if (n == 2) {
		printf("1 1");
		} else if (n > 2 && n <= 40) {
		result[0] = 1;
		result[1] = 1;
		for (i = 2; i < n; i++) {
			result[i] = result[i - 1] + result[i - 2];
		}
		for (i = 0; i < n; i++) {
			if ((i + 1) % 4 == 0) {
				printf("%12ld", result[i]);
				printf("\n");
			} else
				printf("%12ld", result[i]);
		}
	} else
			printf("\nPlease input a valid integer 2<=n<=40\n");

	}
	return EXIT_SUCCESS;
}
