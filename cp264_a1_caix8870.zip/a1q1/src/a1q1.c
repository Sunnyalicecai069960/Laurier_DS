/*
 -------------------------------------------------------
 Project: a1q1
 File:    a1q1.c
 -------------------------------------------------------
 Author:  Tingting Cai
 ID: 174178870
 Email:   caix8870@mylaurier.ca
 Version: 14
 -------------------------------------------------------
 */
#include <stdio.h>
#include <stdlib.h>
int main() {
	char input, enter;
	setbuf(stdout, NULL);
	printf("\n Please enter a character:\n");
	scanf("%c%c", &input, &enter);
	while (input != '*') {
		if (input >= 'a' && input <= 'z') {
			printf("%d  %c", input, input - 32);
		} else if (input >= 'A' && input <= 'Z') {
			printf("%d %c", input, input + 32);
		} else
			printf("please input a valid character such as 'a'");
		printf("\n Please enter a character:\n ");
		scanf("%c%c", &input, &enter);
	}
	printf("Goodbye");
	return 0;
}
