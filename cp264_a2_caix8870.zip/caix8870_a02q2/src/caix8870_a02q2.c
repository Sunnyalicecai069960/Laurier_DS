/*
 ============================================================================
 Name        : caix8870_a02q2.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int evaluate_polynomial(int*, int, int);
int main(int argc, char *args[]) {
	int size = argc - 2;
	int a[size];
	int i;
	int result = 0;
	if (size < 1) {
		printf("please input at least one integer!");
	} else {
	for (i = 0; i < size; i++) {
			a[i] = atoi(args[i + 2]);
	}
		result = evaluate_polynomial(a, size, atoi(args[1]));
		printf("The value of the polynomail at %d is %d", atoi(args[1]),
				result);
	}
	return EXIT_SUCCESS;
}
/*
 * Evaluates a polynomial of n terms. Uses Horner's algorithm.
 * a[] - list of term constants
 * n - number of terms
 * x - value of polynomial variable
 */

int evaluate_polynomial(int *a, int n, int x) {
	int i;
	int b[n - 1];
	b[0] = a[n - 1] * x + a[n - 2];
	for (i = 1; i < (n - 1); i++) {
		b[i] = b[i - 1] * x + a[n - i - 2];
//		printf("%d", a[i]);
	}
	return b[n - 2];
}
