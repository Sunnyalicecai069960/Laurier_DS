/*
 ============================================================================
 Name        : caix8870_a02q3.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

void selection_sort(int a[], int n);
void quick_sort(int *a, int n);
void qs_recursive(int *a, int start, int end);
int main(int argc, char *args[]) {
	int size = argc - 1;
	int input1[size], input2[size];
	int i;

	printf("Array:\n");
	for (i = 0; i < size; i++) {
		printf("%d", atoi(args[i + 1]));
		input1[i] = atoi(args[i + 1]);
		input2[i] = atoi(args[i + 1]);
	}

	selection_sort(input1, size);
	quick_sort(input2, size);

	printf("\nSelection sort result:\n");
	for (i = 0; i < size; i++) {
		printf("%d", input1[i]);
	}
	printf("\nQuick sort result:\n");
	for (i = 0; i < size; i++) {
		printf("%d", input2[i]);
	}
	return EXIT_SUCCESS;
}

void selection_sort(int *a, int n) {
	int i, j;
	int temp;
	int min;

	for (i = 0; i < n; i++) {
		min = i;
		for (j = i + 1; j < n; j++) {
			if (a[min] > a[j])
				min = j;
		}
		temp = a[i];
		a[i] = a[min];
		a[min] = temp;
	}
}

void quick_sort(int *a, int n) {
	qs_recursive(a, 0, n - 1);
}
void qs_recursive(int *a, int start, int end) {
	if (start >= end)
		return;
	int mid = a[start];
	int left, right;
	left = start;
	right = end;

	while (left < right) {
		while (a[right] > mid && left < right) {
			right--;
		}
		a[left] = a[right];
		while (a[left] <= mid && left < right) {
			left++;
		}
		a[right] = a[left];
	}
	a[left] = mid;
	if (left)
		qs_recursive(a, start, left - 1);
	qs_recursive(a, left + 1, end);
}
