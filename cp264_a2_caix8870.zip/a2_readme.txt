Name:Tingting Cai	
ID:174178870
Email:caix8870@mylaurier.ca
Assignment_ID: cp264a2
Homework statement: I claim that the enclosed submission is my individual work 

Check list, self-evaulation/marking, marking scheme:
Note: fill self-evaluation for each of the following bracket under A1 marks and evalutions below. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2  like [2/2]. If 
marker gives different evalution value say 1, it will show [2/2/1] in the marking report. 

a2 marks and evaluations:

Q1
1. correctness of ifib(n)            [4/4]
2. correctness of rfib(n)            [4/4]
3. main function                     [2/2]

Q2
1. honor's algorithm                  [4/4]  0 if not using Horner's method
2. correctness of evaluation          [3/3]
3. main testing                       [3/3] 


Q3
1. array copy                         [2/2]
1. selection sort and correctness     [2/2]
2. quick sort and correctness         [4/4]
3. main test                          [2/2] 


Total:                              [30/30]
