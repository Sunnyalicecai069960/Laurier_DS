/*
 ============================================================================
 Name        : a2q1.c
 Author      : tingting
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int ifib(int n);
int rfib(int n);
int main(void) {
	/**
	 * f(n)=f(n-1)+f(n-2)
	 * iterative algorithem
	 */
	int n; // the input integer
	int i; // the index
	int result1, result2;
	char str[10]; // the input string
	setbuf(stdout, NULL);
	while (1) {
		printf("\na2q1->please input the number:");
		scanf("%s", &str);
		/*
		 * 1,if other data type
		 * 2,if character
		 */
		for (i = 0; i < strlen(str); i++) {
			if (isalpha(str[i]))
				continue;
			if (str[i] == '.')
				continue;
		}
		n = atoi(str);
		fflush(stdin);
		if (n < 0) {
			printf("\n please input a positive number\n");
		} else if (n == 0) {
			result1 = 0;
			printf(
					"Fibonacci - Iterative Algorithm\nifib(%d) = %d \nFibonacci - Recursive Algorithm\nrfib(%d) = %d\nDone",
					n, result1, n, result1);

		} else if (n == 1) {
			result1 = 1;
			printf(
					"Fibonacci - Iterative Algorithm\nifib(%d) = %d \nFibonacci - Recursive Algorithm\nrfib(%d) = %d\nDone",
					n, result1, n, result1);
		} else {
//			int fib[n];
			result1 = ifib(n);

			result2 = rfib(n);

			printf(
					"Fibonacci - Iterative Algorithm\nifib(%d) = %d \nFibonacci - Recursive Algorithm\nrfib(%d) = %d\nDone",
					n, result1, n, result2);
		}
	}
	return EXIT_SUCCESS;
}
int ifib(int n) {
	int *fib = (int *) malloc(sizeof(int) * (n + 1));
	int i;
	fib[0] = 0;
	fib[1] = 1;
	for (i = 2; i < (n + 1); i++) {
		fib[i] = fib[i - 1] + fib[i - 2];
	}
	return fib[n];
}
int rfib(int n) {
	if (n == 1)
		return 1;
	else if (n == 0)
		return 0;
	return rfib(n - 1) + rfib(n - 2);
}
